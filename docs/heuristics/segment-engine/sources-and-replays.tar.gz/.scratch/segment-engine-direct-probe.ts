import fs from "node:fs";
import {isDeepStrictEqual} from "node:util";
import {JavaRandom} from "./segment-engine-fixed-source/src/java-random";
import {routeOrthogonalSegments} from "./segment-engine-fixed-source/src/layered/orthogonal-segments";
import {elkOrthogonalSegments,constraintOracleHash} from "../test/helpers/elk-constraint-oracle";
const rows:any[]=[];
  const gen = new JavaRandom(3468112780);
  for (let index = 0; index < 1024; index++) {
    const segments = Array.from({ length: 2 + gen.nextInt(8) }, () => {
      const incoming = [
        ...new Set(
          Array.from({ length: gen.nextInt(4) }, () =>
            index < 512 ? gen.nextInt(20) * 3 : (gen.nextInt(200) - 100) / 10,
          ),
        ),
      ].sort((a, b) => a - b);
      const outgoing = [
        ...new Set(
          Array.from({ length: incoming.length ? gen.nextInt(4) : 1 + gen.nextInt(3) }, () =>
            index < 512 ? gen.nextInt(20) * 3 : (gen.nextInt(200) - 100) / 10,
          ),
        ),
      ].sort((a, b) => a - b);
      return { incoming, outgoing };
    });
    const input = {
      segments,
      conflictThreshold: index < 512 ? 6 : 2.3,
      criticalThreshold: index < 512 ? 0.6 : 0.23,
      seed: gen.nextInt(2 ** 30),
    };
    const random = new JavaRandom(input.seed),
      actual = routeOrthogonalSegments(
        segments,
        input.conflictThreshold,
        input.criticalThreshold,
        random,
      );
    actual.dependencies.sort((a, b) => a.source - b.source);
    const result={...actual,nextFloat:random.nextFloat()},expected=elkOrthogonalSegments(input);
    rows.push({index,input,actual:result,expected,exact:isDeepStrictEqual(result,expected)});
  }
fs.writeFileSync("docs/heuristics/segment-engine/direct-probe.json",JSON.stringify({baseSeed:3468112780,workerHash:constraintOracleHash,exact:rows.filter(r=>r.exact).length,splitCases:rows.filter(r=>r.actual.segments.length>r.input.segments.length).length,rows},null,2)+"\n");
console.log({exact:rows.filter(r=>r.exact).length,splitCases:rows.filter(r=>r.actual.segments.length>r.input.segments.length).length});
