---
"@statelyai/layout": patch
---

Coordinate native compatibility hierarchy crossing sweeps before placement,
refresh parent dimensions and ports from finished children, and preserve the
selected port order through routing. Align NetworkSimplex traversal with port
order and correct Brandes-Koepf alignment for parallel edges and a shared physical
port. Native hierarchical layout and routing parity remains incomplete.
