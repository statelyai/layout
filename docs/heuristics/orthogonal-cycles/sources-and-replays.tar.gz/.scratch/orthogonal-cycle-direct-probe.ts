import fs from 'node:fs';
import crypto from 'node:crypto';
import {JavaRandom} from '../src/java-random';
import {detectOrthogonalCycles} from '../src/layered/orthogonal-cycle-order';
import {elkOrthogonalCycles, type OrthogonalCycleOracleInput} from '../test/helpers/elk-constraint-oracle';
const generator=new JavaRandom(3468112780);
const rows=[];
for(let index=0;index<512;index++){
 const count=2+generator.nextInt(8),dependencies:OrthogonalCycleOracleInput['dependencies']=[];
 for(let source=0;source<count;source++)for(let target=0;target<count;target++)if(source!==target&&generator.nextInt(5)===0)dependencies.push({source,target,weight:generator.nextInt(5),critical:generator.nextBoolean()});
 const input={count,dependencies,criticalOnly:index%2===0,seed:generator.nextInt(2**30)};
 const random=new JavaRandom(input.seed),result=detectOrthogonalCycles(count,dependencies,input.criticalOnly,random);
 const actual={...result,nextFloat:random.nextFloat()},expected=elkOrthogonalCycles(input);
 rows.push({index,input,actual,expected,exact:JSON.stringify(actual)===JSON.stringify(expected)});
}
const workerHash=crypto.createHash('sha256').update(fs.readFileSync('node_modules/elkjs/lib/elk-worker.js')).digest('hex');
fs.writeFileSync('docs/heuristics/orthogonal-cycles/direct-probe.json',JSON.stringify({baseSeed:3468112780,workerHash,exact:rows.filter(r=>r.exact).length,rows},null,2)+'\n');
console.log(rows.filter(r=>r.exact).length);
