import fs from "node:fs";
import {routeToPolylines} from './joined-compaction-fixed-source/src';
import {measureQuality} from '../scripts/heuristic-quality.mjs';
import {fromElkOutput} from '../scripts/heuristic-elk-comparison.mjs';
const escape=(s:any)=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const colors=['#2563eb','#9333ea','#059669','#d97706','#db2777'];
function renderScene(layout, routes, input, title, prefix) {
  const byId = new Map(layout.nodes.map((n) => [n.id, n]));
  const world = layout.nodes.map((node) => {
    let x = node.x,
      y = node.y,
      parent = node.parentId;
    while (parent) {
      const ancestor = byId.get(parent);
      x += ancestor.x;
      y += ancestor.y;
      parent = ancestor.parentId;
    }
    return { ...node, x, y };
  });

  const paths = layout.edges.flatMap((edge) => {
    const route = routes.get(edge.id);
    return (route ? routeToPolylines(route) : [edge.points ?? []]).map((points, section) => ({
      edgeId: edge.id,
      section,
      points,
    }));
  });
  for (const rect of [...world, ...layout.edges])
    if (![rect.x, rect.y, rect.width, rect.height].every(Number.isFinite))
      throw new Error(`Non-finite geometry: ${rect.id}`);
  for (const path of paths)
    for (const point of path.points)
      if (![point.x, point.y].every(Number.isFinite))
        throw new Error(`Non-finite route: ${path.edgeId}`);
  const points = [
    ...world.flatMap((n) => [
      { x: n.x, y: n.y },
      { x: n.x + n.width, y: n.y + n.height },
    ]),
    ...layout.edges.flatMap((e) => [
      { x: e.x, y: e.y },
      { x: e.x + e.width, y: e.y + e.height },
    ]),
    ...paths.flatMap((p) => p.points),
  ];
  const x = Math.min(...points.map((p) => p.x)) - 24,
    y = Math.min(...points.map((p) => p.y)) - 24;
  const width = Math.max(...points.map((p) => p.x)) - x + 24,
    height = Math.max(...points.map((p) => p.y)) - y + 24;
  const containers = new Set(input.nodes.map((n) => n.parentId).filter(Boolean));
  const rects = world
    .map(
      (n) =>
        `<g><title>${escape(n.id)} · ${n.width} × ${n.height} · parent ${n.parentId ?? "none"}</title><rect x="${n.x}" y="${n.y}" width="${n.width}" height="${n.height}" rx="6" fill="${containers.has(n.id) ? "#f1f5f9" : "#fff"}" stroke="#94a3b8"/><text x="${n.x + 10}" y="${n.y + 23}" font-size="13">${n.id}</text></g>`,
    )
    .join("");
  const lines = paths
    .map((p) => {
      const edge = input.edges.find((e) => e.id === p.edgeId);
      const color = colors[(Number(p.edgeId.slice(1)) - 1) % colors.length];
      const last = paths.filter((s) => s.edgeId === p.edgeId).at(-1) === p;
      return `<polyline points="${p.points.map((p) => `${p.x},${p.y}`).join(" ")}" fill="none" stroke="${color}" stroke-width="1.8" ${last ? `marker-end="url(#${prefix}-arrow${colors.indexOf(color)})"` : ""}><title>${p.edgeId}: ${edge.sourceId}${edge.sourcePort ? `:${edge.sourcePort}` : ""} → ${edge.targetId}${edge.targetPort ? `:${edge.targetPort}` : ""}</title></polyline>`;
    })
    .join("");
  const labels = layout.edges
    .filter((e) => e.width)
    .map(
      (e) =>
        `<rect x="${e.x}" y="${e.y}" width="${e.width}" height="${e.height}" rx="4" fill="#fff" stroke="#cbd5e1"/><text x="${e.x + 8}" y="${e.y + 15}" font-size="11">${e.id}</text>`,
    )
    .join("");
  const ports = world
    .flatMap((n) =>
      (n.ports ?? []).map(
        (p) =>
          `<circle cx="${n.x + p.x + (p.width ?? 0) / 2}" cy="${n.y + p.y + (p.height ?? 0) / 2}" r="3.5" fill="#0f172a"><title>${n.id}:${p.name}</title></circle>`,
      ),
    )
    .join("");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x} ${y} ${width} ${height}" role="img" aria-label="${escape(title)}" style="font-family:system-ui;background:white"><defs>${colors.map((color, i) => `<marker id="${prefix}-arrow${i}" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L6,3 L0,6" fill="${color}"/></marker>`).join("")}</defs>${rects}${lines}${labels}${ports}</svg>`;

  const diagonalSegments = paths.reduce(
    (sum, path) =>
      sum +
      path.points
        .slice(1)
        .filter(
          (p, i) =>
            Math.abs(p.x - path.points[i].x) > 1e-6 && Math.abs(p.y - path.points[i].y) > 1e-6,
        ).length,
    0,
  );
  return {
    metrics: measureQuality({ ...layout, routes: [...routes] }, input),
    svg,
    bounds: { x, y, width, height },
    stats: {
      fallbackRoutes: [...routes.values()].filter((r) => r.status !== "routed").length,
      diagonalSegments,
      blockedRoutes: [...routes.values()].filter((r) =>
        r.diagnostics.some((d) => d.code === "ROUTE_BLOCKED"),
      ).length,
      budgetFailures: [...routes.values()].filter((r) =>
        r.diagnostics.some((d) => d.code === "SEARCH_BUDGET"),
      ).length,
      routeConflicts: [...routes.values()].filter((r) =>
        r.diagnostics.some((d) => d.code === "ROUTE_CONFLICT"),
      ).length,
    },
    layout: {
      nodes: layout.nodes,
      edges: layout.edges,
      routes: [...routes],
      compoundGeometry: [...(layout.compoundGeometry ?? [])],
    },
  };
}

const report=JSON.parse(fs.readFileSync('.scratch/joined-compaction-native-probe.json','utf8'));
const destination='docs/heuristics/joined-compaction';
let sections='';
for(const row of report.rows){
 const scenes:any[]=[];
 if(row.after.output){const native={...row.after.output,compoundGeometry:undefined};
 scenes.push(renderScene(native,new Map(native.routes),row.input,'Stately native',`native-${row.id}`));}
 if(row.elk.output){const converted=fromElkOutput(row.elk.output,row.input);scenes.push(renderScene(converted.layout,converted.routes,row.input,'Real ELK',`elk-${row.id}`));}
 const x=Math.min(...scenes.map(s=>s.bounds.x)),y=Math.min(...scenes.map(s=>s.bounds.y));
 const width=Math.max(...scenes.map(s=>s.bounds.x+s.bounds.width))-x,height=Math.max(...scenes.map(s=>s.bounds.y+s.bounds.height))-y;
 const pair=scenes.map((s,index)=>{
  const svg=s.svg.replace(/viewBox="[^"]*"/,`viewBox="${x} ${y} ${width} ${height}"`);
  const filename=`graph-${row.id}-${(row.after.error||index)?'elk':'native'}.svg`;fs.writeFileSync(`${destination}/${filename}`,svg);
  const isElk=Boolean(row.after.error)||index===1;
  const metric=isElk?row.elk.metrics:row.after.metrics;
  return `<div><p>${isElk?'Real ELK':'Stately native'} · ${metric.edgeCrossings} crossings · ${metric.bends} bends</p><a href="${filename}"><img src="${filename}" alt="${isElk?'Real ELK':'Stately native'} graph ${row.id}"></a></div>`;
 }).join('');
 sections+=`<section id="graph-${row.id}"><h2>Graph ${row.id} · ${row.direction} · seed ${row.seed}</h2><div class="pair">${row.after.error?`<div><p>Stately native error</p><pre>${escape(row.after.error)}</pre></div>`:""}${pair}${row.elk.error?`<div><p>Real ELK error</p><pre>${escape(row.elk.error)}</pre></div>`:''}</div></section>`;
}
fs.writeFileSync(`${destination}/index.html`,`<!doctype html><meta charset="utf-8"><title>Native joined compaction / real ELK</title><style>body{font:15px system-ui;margin:24px;background:#f8fafc}.pair{display:grid;grid-template-columns:1fr 1fr;gap:16px}img{width:100%;background:white}section{margin-bottom:32px}pre{white-space:pre-wrap}</style><h1>Native joined compaction / real ELK</h1><p>Saved base seed 3468112780. Same input and direction; each pair shares its viewport and scale. Full parity still fails. Click a diagram to inspect its SVG.</p>${sections}`);
