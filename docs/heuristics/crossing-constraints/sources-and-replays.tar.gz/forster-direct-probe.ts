import fs from 'node:fs';
import {JavaRandom} from '../src/java-random';
import {resolveCrossingConstraints as Corrected, type CrossingUnits} from '../src/layered/crossing-constraints';
import {resolveCrossingConstraints as First} from './crossing-units-candidate/src/layered/crossing-constraints';
import {elkResolveConstraints, constraintOracleHash, type ConstraintOracleInput} from '../test/helpers/elk-constraint-oracle';
const rows:any[]=[];
  const random = new JavaRandom(3468112780);
  for (let index = 0; index < 512; index++) {
    const seed: string[] = [],
      normals: string[] = [],
      units: [string, string][] = [],
      successors = new Map<string, string[]>(),
      scores: Record<string, number> = {};
    const count = 2 + Math.floor(random.nextDouble() * 4);
    const normalConstraints = index % 2 === 0;
    for (let u = 0; u < count; u++) {
      const owner = `n${u}`;
      normals.push(owner);
      const north = Array.from(
        { length: Math.floor(random.nextDouble() * 3) },
        (_, i) => `${owner}:north${i}`,
      );
      const south = Array.from(
        { length: Math.floor(random.nextDouble() * 3) },
        (_, i) => `${owner}:south${i}`,
      );
      for (const id of [...north, owner, ...south]) {
        seed.push(id);
        units.push([id, owner]);
        scores[id] =
          index % 3 === 0 ? Math.floor(random.nextDouble() * 8) : random.nextDouble() * 10;
      }
      for (const id of north) successors.set(id, [owner]);
      successors.set(owner, south);
      if (normalConstraints && u > 0)
        successors.set(normals[u - 1]!, [...(successors.get(normals[u - 1]!) ?? []), owner]);
    }
    const order = [...seed].sort((a, b) => scores[a]! - scores[b]!);
    const input: ConstraintOracleInput = {
      seed,
      order,
      normals,
      units,
      successors: [...successors],
      scores,
      normalConstraints,
    };
    const unitMembers = new Map<string, string[]>();
    for (const [id, owner] of units)
      unitMembers.set(owner, [...(unitMembers.get(owner) ?? []), id]);
    const state: CrossingUnits = {
      units: new Map(units),
      unitMembers,
      successors,
      normalNodes: new Set(normals),
      associates: new Map(),
      constraintsBetweenNormalNodes: normalConstraints,
    };

    const row:any={index,input,oracle:elkResolveConstraints(input)};
    for(const [name,resolve] of [['first',First],['corrected',Corrected]] as const){
      const barycenters=new Map(Object.entries(scores));
      try { const order=resolve(input.order,barycenters,state); row[name]={order,scores:Object.fromEntries(barycenters)}; }
      catch(error){row[name]={error:String(error)};}
    }
    row.exact=JSON.stringify(row.corrected)===JSON.stringify(row.oracle);
    rows.push(row);
  }
fs.writeFileSync('.scratch/forster-direct-probe.json',JSON.stringify({baseSeed:3468112780,oracleSourceHash:constraintOracleHash,oracleVersion:JSON.parse(fs.readFileSync('node_modules/elkjs/package.json','utf8')).version,rows},null,2));
console.log(JSON.stringify({count:rows.length,firstErrors:rows.filter(r=>r.first.error).length,correctedExact:rows.filter(r=>r.exact).length}));
