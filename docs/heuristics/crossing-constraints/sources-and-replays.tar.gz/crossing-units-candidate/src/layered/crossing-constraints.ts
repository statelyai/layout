/*******************************************************************************
 * Copyright (c) 2016, 2020 Kiel University and others.
 * Adapted from ELK v0.11.0 ForsterConstraintResolver and BarycenterHeuristic.
 * Source commit: 54123e884b1ae743b453260f713b20c9bf5787f2
 * SPDX-License-Identifier: EPL-2.0
 *******************************************************************************/
import type { JavaRandom } from "../java-random";
import type { LayeredPhaseInput } from "./types";
export interface CrossingUnits {
  successors: ReadonlyMap<string, readonly string[]>;
  units: ReadonlyMap<string, string>;
  unitMembers?: ReadonlyMap<string, readonly string[]>;
  associates: ReadonlyMap<string, readonly string[]>;
  normalNodes: ReadonlySet<string>;
  longEdgeNodes?: ReadonlySet<string>;
  northEdges?: ReadonlySet<string>;
  southEdges?: ReadonlySet<string>;
  constraintsBetweenNormalNodes?: boolean;
}
const unitState = new WeakMap<LayeredPhaseInput, CrossingUnits>();
export const recordCrossingUnits = (input: LayeredPhaseInput, state: CrossingUnits): void => {
  unitState.set(input, state);
};
export const getCrossingUnits = (input: LayeredPhaseInput): CrossingUnits | undefined =>
  unitState.get(input);

/** Recursively include same-layer neighbors and owner associates before perturbation. */
export function associatedBarycenters(
  layer: readonly string[],
  ranks: ReadonlyMap<string, readonly number[]>,
  sameLayerNeighbors: ReadonlyMap<string, readonly string[]>,
  associates: ReadonlyMap<string, readonly string[]>,
  random?: JavaRandom,
): Map<string, number | undefined> {
  const states = new Map(
    layer.map((id) => [
      id,
      { visited: false, degree: 0, weight: 0, barycenter: undefined as number | undefined },
    ]),
  );
  const calculate = (id: string): void => {
    const state = states.get(id);
    if (!state || state.visited) return;
    state.visited = true;
    for (const rank of ranks.get(id) ?? []) {
      state.degree++;
      state.weight += rank;
    }
    for (const neighbor of [...(sameLayerNeighbors.get(id) ?? []), ...(associates.get(id) ?? [])]) {
      if (neighbor === id) continue;
      calculate(neighbor);
      const other = states.get(neighbor);
      if (other) {
        state.degree += other.degree;
        state.weight += other.weight;
      }
    }
    if (state.degree > 0) {
      state.weight += random ? random.nextFloat() * Math.fround(0.07) - Math.fround(0.07) / 2 : 0;
      state.barycenter = state.weight / state.degree;
    }
  };
  for (const id of layer) calculate(id);
  return new Map([...states].map(([id, s]) => [id, s.barycenter]));
}

interface Group {
  nodes: string[];
  barycenter: number;
  outgoing: Group[];
}
/** Resolve successor and layout-unit constraints by merging violated groups in barycenter order. */
export function resolveCrossingConstraints(
  order: readonly string[],
  barycenters: Map<string, number | undefined>,
  state: CrossingUnits,
): string[] {
  if (state.constraintsBetweenNormalNodes) {
    const normalOnly = new Map(
      [...state.successors]
        .filter(([id]) => state.normalNodes.has(id))
        .map(([id, targets]) => [id, targets.filter((target) => state.normalNodes.has(target))]),
    );
    const first = resolveCrossingConstraints(order, barycenters, {
      ...state,
      successors: normalOnly,
      units: new Map(),
      unitMembers: new Map(),
      constraintsBetweenNormalNodes: false,
    });
    return resolveCrossingConstraints(first, barycenters, {
      ...state,
      constraintsBetweenNormalNodes: false,
    });
  }
  const groups: Group[] = order.map((id) => ({
    nodes: [id],
    barycenter: barycenters.get(id) ?? 0,
    outgoing: [],
  }));
  const byId = new Map(groups.map((g) => [g.nodes[0]!, g]));
  const units = new Map<string, string[]>();
  if (state.unitMembers) {
    for (const [owner, members] of state.unitMembers)
      units.set(
        owner,
        members.filter((id) => byId.has(id)),
      );
  } else
    for (const [id, owner] of state.units)
      if (byId.has(id)) units.set(owner, [...(units.get(owner) ?? []), id]);
  let previous: string | undefined;
  for (const id of order) {
    const group = byId.get(id)!;
    for (const successor of state.successors.get(id) ?? []) {
      const target = byId.get(successor);
      if (target) group.outgoing.push(target);
    }
    if (state.normalNodes.has(id)) {
      if (previous !== undefined)
        for (const left of units.get(previous) ?? [])
          for (const right of units.get(id) ?? []) byId.get(left)!.outgoing.push(byId.get(right)!);
      previous = id;
    }
  }
  const violation = (): [Group, Group] | undefined => {
    const incomingCount = new Map(groups.map((g) => [g, 0]));
    const incoming = new Map(groups.map((g) => [g, [] as Group[]]));
    for (const g of groups)
      for (const target of g.outgoing) incomingCount.set(target, incomingCount.get(target)! + 1);
    const active = groups.filter((g) => g.outgoing.length && incomingCount.get(g) === 0);
    for (let index = 0; index < active.length; index++) {
      const group = active[index]!;
      for (const predecessor of incoming.get(group)!) {
        const equal = predecessor.barycenter === group.barycenter;
        if (
          equal
            ? groups.indexOf(predecessor) > groups.indexOf(group)
            : predecessor.barycenter > group.barycenter
        )
          return [predecessor, group];
      }
      for (const target of group.outgoing) {
        const predecessors = incoming.get(target)!;
        predecessors.unshift(group);
        if (predecessors.length === incomingCount.get(target)) active.push(target);
      }
    }
    return undefined;
  };
  let pair: [Group, Group] | undefined;
  while ((pair = violation())) {
    const [first, second] = pair;
    // ELK initializes ConstraintGroup degree/weight to zero, so actual merges
    // average the two group barycenters (not their node or edge counts).
    const merged: Group = {
      nodes: [...first.nodes, ...second.nodes],
      barycenter: (first.barycenter + second.barycenter) / 2,
      outgoing: first.outgoing.filter((g) => g !== second),
    };
    for (const target of second.outgoing)
      if (target !== first && !merged.outgoing.includes(target)) merged.outgoing.push(target);
    const survivors = groups.filter((g) => g !== first && g !== second);
    for (const group of survivors) {
      const firstIndex = group.outgoing.indexOf(first),
        secondIndex = group.outgoing.indexOf(second);
      if (firstIndex >= 0) group.outgoing.splice(firstIndex, 1);
      const remainingSecond = group.outgoing.indexOf(second);
      if (remainingSecond >= 0) group.outgoing.splice(remainingSecond, 1);
      if (firstIndex >= 0 || secondIndex >= 0) group.outgoing.push(merged);
    }
    const index = survivors.findIndex((g) => g.barycenter > merged.barycenter);
    survivors.splice(index < 0 ? survivors.length : index, 0, merged);
    groups.splice(0, groups.length, ...survivors);
  }
  for (const group of groups) for (const id of group.nodes) barycenters.set(id, group.barycenter);
  return groups.flatMap((g) => g.nodes);
}

/** ELK greedy switches must preserve port-unit and explicit successor constraints. */
export function canSwapCrossingUnits(upper: string, lower: string, state: CrossingUnits): boolean {
  if (state.successors.get(upper)?.includes(lower)) return false;
  const up = state.units.get(upper),
    down = state.units.get(lower);
  const upperDummy = up !== undefined && up !== upper,
    lowerDummy = down !== undefined && down !== lower;
  const different = up !== down;
  const constrained =
    upperDummy || lowerDummy || state.southEdges?.has(upper) || state.northEdges?.has(lower);
  if (state.northEdges?.has(upper) || state.southEdges?.has(lower)) return false;
  if (
    !state.longEdgeNodes?.has(upper) &&
    !state.longEdgeNodes?.has(lower) &&
    constrained &&
    different
  )
    return false;
  if ((upperDummy && state.normalNodes.has(lower)) || (lowerDummy && state.normalNodes.has(upper)))
    return false;
  return true;
}
