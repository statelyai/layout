import fs from 'node:fs';
import Native from '../src/elkjs';
import Before from './crossing-units-full-before/src/elkjs';
import Oracle from 'elkjs/lib/elk.bundled.js';
const fixture=JSON.parse(fs.readFileSync('test/fixtures/email-drafter-viz.json','utf8'));
const rows:any[]=[];
for(const direction of ['DOWN','UP','RIGHT','LEFT']) {
 const input=structuredClone(fixture);input.layoutOptions['elk.direction']=direction;
 const row:any={direction,input};
 for(const [name,Engine] of [['before',Before],['current',Native],['elk',Oracle]] as const) {
  try {
   const output=await new Engine().layout(structuredClone(input));const owners=new Map(output.children.flatMap((n:any)=>[[n.id,n],...(n.ports??[]).map((p:any)=>[p.id,n])]));
   const axis=direction==='RIGHT'||direction==='LEFT'?'x':'y',size=axis==='x'?'width':'height';
   const failures=output.edges.flatMap((e:any)=>{
    const source:any=owners.get(e.sources[0]),target:any=owners.get(e.targets[0]);if(source===target)return [];
    const start=Math.min(source[axis]+source[size],target[axis]+target[size]),end=Math.max(source[axis],target[axis]);
    return (e.labels??[]).filter((l:any)=>l[axis]<start||l[axis]+l[size]>end).map((l:any)=>({edge:e.id,source:source.id,target:target.id,start,end,label:l[axis],labelEnd:l[axis]+l[size]}));
   });row[name]={output,failures};
  }catch(error){row[name]={error:String(error)};}
 }
 rows.push(row);console.log(JSON.stringify({direction,...Object.fromEntries(['before','current','elk'].map(name=>[name,row[name].failures??row[name].error]))}));
}
fs.writeFileSync('.scratch/email-crossing-unit-probe.json',JSON.stringify({rows},null,2));
