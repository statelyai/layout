import fs from 'node:fs';
import vm from 'node:vm';
const context={console,setTimeout,clearTimeout,module:{exports:{}}};
context.global=context;context.exports=context.module.exports;
vm.createContext(context);
vm.runInContext(fs.readFileSync('node_modules/elkjs/lib/elk-worker.js','utf8'),context,{timeout:20000});
console.log(['LGraph','LNode','Layer','ForsterConstraintResolver','$processConstraints','$setProperty_0'].map(k=>[k,typeof context[k]]));
const graph=new context.LGraph(); const layer=new context.Layer(graph);console.log(Object.keys(layer));
function resolve(data){
 const graph=new context.LGraph(),layer=new context.Layer(graph);layer.id_0=0;
 const nodes=data.seed.map((id,i)=>{const n=new context.LNode(graph);n.layer=layer;n.id_0=i;n.name=id;n.type_0=data.normals.includes(id)?context.NORMAL:context.NORTH_SOUTH_PORT;return n;});
 const byId=new Map(nodes.map(n=>[n.name,n]));context.$clinit_InternalProperties_1();
 for(const [id,owner] of data.units)context.$setProperty_0(byId.get(id),context.IN_LAYER_LAYOUT_UNIT,byId.get(owner));
 for(const [id,targets] of data.successors){const list=context.$getProperty(byId.get(id),context.IN_LAYER_SUCCESSOR_CONSTRAINTS);for(const target of targets)list.add_2(byId.get(target));}
 const resolver=new context.ForsterConstraintResolver([nodes]);resolver.initAtLayerLevel(0,[nodes]);
 for(let i=0;i<nodes.length;i++){resolver.initAtNodeLevel(0,i,[nodes]);resolver.barycenterStates[0][i].barycenter=data.scores[nodes[i].name];}
 const list=new context.ArrayList();for(const id of data.order)list.add_2(byId.get(id));context.$processConstraints(resolver,list);
 return {order:list.array.map(n=>n.name),scores:Object.fromEntries(nodes.map(n=>[n.name,resolver.barycenterStates[0][n.id_0].barycenter]))};
}
console.log(resolve({seed:['a','b','c'],order:['b','c','a'],normals:[],units:[],successors:[['a',['b']]],scores:{a:10,b:0,c:4}}));
