import { execFileSync } from "node:child_process";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

type PackResult = { filename: string };
type PackageJson = { exports: Record<string, unknown> };

const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const checkedExports = new Set([
  ".",
  "./elkjs",
  "./layered",
  "./routing",
  "./lib/elk-api.js",
  "./lib/elk.bundled.js",
  "./lib/elk-worker.js",
  "./lib/elk-worker.min.js",
  "./lib/main.js",
]);

async function main(): Promise<void> {
  const packageJson = JSON.parse(
    await readFile(join(rootDir, "package.json"), "utf8"),
  ) as PackageJson;
  const publishedExports = Object.keys(packageJson.exports).filter(
    (key) => key !== "./package.json",
  );
  const missing = publishedExports.filter((key) => !checkedExports.has(key));
  const stale = [...checkedExports].filter((key) => !publishedExports.includes(key));
  if (missing.length > 0 || stale.length > 0) {
    throw new Error(
      `Package smoke coverage mismatch: missing ${missing.join(", ") || "none"}; stale ${stale.join(", ") || "none"}`,
    );
  }

  const packOutput = execFileSync("npm", ["pack", "--json", "--ignore-scripts"], {
    cwd: rootDir,
    encoding: "utf8",
  });
  const jsonStart = packOutput.indexOf("[");
  const jsonEnd = packOutput.lastIndexOf("]");
  if (jsonStart < 0 || jsonEnd < jsonStart) {
    throw new Error(`Unable to parse npm pack output:\n${packOutput}`);
  }
  const [{ filename }] = JSON.parse(packOutput.slice(jsonStart, jsonEnd + 1)) as PackResult[];
  const tarballPath = join(rootDir, filename);
  const tempDir = await mkdtemp(join(tmpdir(), "statelyai-layout-smoke-"));
  const consumerDir = join(tempDir, "consumer");

  try {
    await mkdir(consumerDir, { recursive: true });
    await writeFile(
      join(consumerDir, "package.json"),
      `${JSON.stringify(
        {
          name: "layout-smoke-consumer",
          private: true,
          type: "module",
          packageManager: "pnpm@10.28.2",
        },
        null,
        2,
      )}\n`,
    );
    execFileSync(
      "corepack",
      ["pnpm", "add", "--ignore-workspace", tarballPath, "@statelyai/graph@^2.1.0"],
      {
        cwd: consumerDir,
        stdio: "inherit",
      },
    );
    execFileSync(
      "corepack",
      ["pnpm", "add", "--ignore-workspace", "--save-dev", "typescript@^5.9.3"],
      {
        cwd: consumerDir,
        stdio: "inherit",
      },
    );

    const runtimePath = join(consumerDir, "check.mjs");
    await writeFile(
      runtimePath,
      `import assert from "node:assert/strict";
import { createGraph, getDiff } from "@statelyai/graph";
import { getBoxLayout, getLayeredLayout, getRandomLayout, getLayout, c } from "@statelyai/layout";
import { orthogonalRouting, toSvgPath, applyRoutePatches, getLayoutRoutes } from "@statelyai/layout/routing";
import ELK, { layoutStatechart, compileStatechartLayout, scoreStatechartLayout } from "@statelyai/layout/elkjs";
import ApiELK from "@statelyai/layout/lib/elk-api.js";
import BundledELK from "@statelyai/layout/lib/elk.bundled.js";
import { Worker } from "@statelyai/layout/lib/elk-worker.js";
import { Worker as MinifiedWorker } from "@statelyai/layout/lib/elk-worker.min.js";
import MainELK from "@statelyai/layout/lib/main.js";
import { getLayeredLayout as getLayeredLayoutFromSubpath } from "@statelyai/layout/layered";
const graph = createGraph({ nodes: [{ id: "a" }, { id: "b" }], edges: [{ id: "ab", sourceId: "a", targetId: "b" }] });
assert.equal(getLayeredLayout(graph).nodes.length, 2);
assert.equal(getBoxLayout(graph).nodes.length, 2);
assert.equal(getRandomLayout(graph, { seed: 1 }).nodes.length, 2);
assert.equal(getLayeredLayoutFromSubpath(graph).edges.length, 1);
const visual = getLayeredLayout(graph);
const routing = orthogonalRouting.route(visual);
assert.equal(routing.routes.size, 1);
assert.match(toSvgPath(routing.routes.get("ab").sections[0].path), /^M /);
const moved = { ...visual, nodes: visual.nodes.map((n, i) => i === 0 ? { ...n, y: n.y + 10 } : n) };
const routeUpdate = orthogonalRouting.update(moved, routing, getDiff(visual, moved));
assert.equal(routeUpdate.base, routing);
assert.deepEqual([...applyRoutePatches(routing.routes, routeUpdate.patches)], [...routeUpdate.snapshot.routes]);
assert.equal(getLayoutRoutes(visual).size, 1);
const partial = await getLayout({ graph: visual, scope: { mode: "partial", edgeIds: ["ab"], edgeGeometry: "labels" }, constraints: [c.pin({ id: "label", entity: { edgeId: "ab", part: "label" }, x: 123 })] });
assert.equal(partial.graph.edges[0].x, 123);
assert.deepEqual(partial.graph.nodes, visual.nodes);
assert.deepEqual(partial.graph.edges[0].points, visual.edges[0].points);
const legacy = await new ELK().layout({ id: "root", children: [{ id: "a" }, { id: "b" }], edges: [{ id: "ab", sources: ["a"], targets: ["b"] }] });
assert.equal(legacy.children?.length, 2);
const policyInput = { id: "root", children: [{ id: "a", width: 80, height: 40 }, { id: "b", width: 80, height: 40 }], edges: [{ id: "ab", sources: ["a"], targets: ["b"] }] };
const policy = await layoutStatechart(policyInput, { scopes: { root: { initialNodeId: "a" } } });
assert.equal(policy.score.pathOrder, 0);
assert.deepEqual(compileStatechartLayout(policyInput, { root: { initialNodeId: "a" } }).paths.root, ["a", "b"]);
assert.equal(scoreStatechartLayout(policy.graph).invalid, 0);
let workerCreated = false;
const apiElk = new ApiELK({ workerFactory: () => { workerCreated = true; return new Worker(); } });
assert.equal(workerCreated, true);
assert.equal((await apiElk.layout({ id: "root" })).id, "root");
apiElk.terminateWorker();
const minifiedApiElk = new ApiELK({ workerFactory: () => new MinifiedWorker() });
assert.equal((await minifiedApiElk.layout({ id: "root" })).id, "root");
minifiedApiElk.terminateWorker();
assert.equal((await new BundledELK().layout({ id: "root" })).id, "root");
assert.equal((await new MainELK().layout({ id: "root" })).id, "root");
let mainWorkerCreated = false;
const factoryMain = new MainELK({ workerFactory: () => { mainWorkerCreated = true; return new Worker(); } });
assert.equal(mainWorkerCreated, true);
factoryMain.terminateWorker();
const workerMain = new MainELK({ workerUrl: "./lib/elk-worker.js" });
assert.equal((await workerMain.layout({ id: "root" })).id, "root");
workerMain.terminateWorker();
const minifiedWorkerMain = new MainELK({ workerUrl: "./lib/elk-worker.min.js" });
assert.equal((await minifiedWorkerMain.layout({ id: "root" })).id, "root");
minifiedWorkerMain.terminateWorker();
`,
    );
    execFileSync("node", [runtimePath], { cwd: consumerDir, stdio: "inherit" });

    const commonJsPath = join(consumerDir, "check.cjs");
    await writeFile(
      commonJsPath,
      `const assert = require("node:assert/strict");
const { getLayout, c } = require("@statelyai/layout");
const { orthogonalRouting, toSvgPath } = require("@statelyai/layout/routing");
const { createGraph } = require("@statelyai/graph");
const MainELK = require("@statelyai/layout/lib/main.js");
const ApiELK = require("@statelyai/layout/lib/elk-api.js");
const BundledELK = require("@statelyai/layout/lib/elk.bundled.js");
const { Worker } = require("@statelyai/layout/lib/elk-worker.js");
const { Worker: MinifiedWorker } = require("@statelyai/layout/lib/elk-worker.min.js");
(async () => {
  const native = await getLayout({ graph: createGraph({ nodes: [{ id: "a" }], edges: [] }), constraints: [c.pin({ id: "pin", entity: { nodeId: "a" }, x: 42 })] });
  assert.equal(native.graph.nodes[0].x, 42);
  assert.equal(orthogonalRouting.route(native.graph).routes.size, 0);
  assert.equal(toSvgPath({ start: { x: 0, y: 0 }, segments: [{ kind: "line", to: { x: 10, y: 20 } }] }), "M 0 0 L 10 20");
  assert.equal((await new MainELK().layout({ id: "root" })).id, "root");
  assert.equal((await new BundledELK().layout({ id: "root" })).id, "root");
  const apiElk = new ApiELK({ workerFactory: () => new Worker() });
  assert.equal((await apiElk.layout({ id: "root" })).id, "root");
  apiElk.terminateWorker();
  const minifiedApiElk = new ApiELK({ workerFactory: () => new MinifiedWorker() });
  assert.equal((await minifiedApiElk.layout({ id: "root" })).id, "root");
  minifiedApiElk.terminateWorker();
  const workerMain = new MainELK({ workerUrl: "./lib/elk-worker.js" });
  assert.equal((await workerMain.layout({ id: "root" })).id, "root");
  workerMain.terminateWorker();
  const minifiedWorkerMain = new MainELK({ workerUrl: "./lib/elk-worker.min.js" });
  assert.equal((await minifiedWorkerMain.layout({ id: "root" })).id, "root");
  minifiedWorkerMain.terminateWorker();
})();
`,
    );
    execFileSync("node", [commonJsPath], { cwd: consumerDir, stdio: "inherit" });

    const typesPath = join(consumerDir, "check.ts");
    await writeFile(
      typesPath,
      `import { createGraph, getDiff } from "@statelyai/graph";
import { getBoxLayout, getLayeredLayout, getRandomLayout, getLayout, c, type LayoutResult } from "@statelyai/layout";
import ELK, { layoutStatechart, type StatechartLayoutOptions, type ElkNode } from "@statelyai/layout/elkjs";
import ApiELK from "@statelyai/layout/lib/elk-api.js";
import BundledELK from "@statelyai/layout/lib/elk.bundled.js";
import { Worker } from "@statelyai/layout/lib/elk-worker.js";
import { type LayeredLayoutOptions } from "@statelyai/layout/layered";
import { orthogonalRouting, type RoutingStrategy, type RoutingSnapshot } from "@statelyai/layout/routing";
const graph = createGraph({ nodes: [{ id: "a" }], edges: [] });
const options: LayeredLayoutOptions = { direction: "right" };
const snapshot: RoutingSnapshot = orthogonalRouting.route(graph);
const update = orthogonalRouting.update(graph, snapshot, getDiff(graph, graph));
const asyncStrategy: RoutingStrategy = { id: "custom-worker", route: async (g, s) => orthogonalRouting.route(g, s), update: async (g, p, d, s) => orthogonalRouting.update(g, p, d, s) };
void update; void asyncStrategy;
getLayout({ graph, scope: { mode: "partial", edgeIds: [], edgeGeometry: "labels" }, constraints: [c.align({ id: "alignment", entities: [{ nodeId: "a" }], axis: "x" })] });
getLayeredLayout(graph, options).nodes[0]?.id;
getBoxLayout(graph, { aspectRatio: 1.3 }).nodes[0]?.id;
getRandomLayout(graph, { seed: 1 }).nodes[0]?.id;
const request: Promise<ElkNode> = new ELK().layout({ id: "root" });
const bundledRequest: Promise<ElkNode> = new BundledELK().layout({ id: "root" });
const apiRequest: Promise<ElkNode> = new ApiELK({ workerFactory: () => new Worker() }).layout({ id: "root" });
void request;
void bundledRequest;
void apiRequest;
const policyOptions: StatechartLayoutOptions = { scopes: { root: { direction: "DOWN" } } };
layoutStatechart({ id: "root" }, policyOptions).then((policy) => { policy.graph.id; });
const result = undefined as unknown as LayoutResult;
void result;
`,
    );
    execFileSync(
      "corepack",
      [
        "pnpm",
        "exec",
        "tsc",
        "--noEmit",
        "--moduleResolution",
        "bundler",
        "--module",
        "preserve",
        "--target",
        "esnext",
        "--strict",
        "--skipLibCheck",
        typesPath,
      ],
      { cwd: consumerDir, stdio: "inherit" },
    );
    console.log("Package smoke test passed");
  } finally {
    await rm(tempDir, { recursive: true, force: true });
    await rm(tarballPath, { force: true });
  }
}

await main();
