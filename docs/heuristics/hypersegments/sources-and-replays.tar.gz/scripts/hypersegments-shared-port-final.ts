import fs from 'node:fs';
import {isDeepStrictEqual} from 'node:util';
import Native from './hypersegments-final-source/src/elkjs';
import Before from './segment-engine-fixed-source/src/elkjs';
import Oracle from 'elkjs/lib/elk.bundled.js';
import {sharedPortFixture} from '../test/helpers/shared-port-fixture';
const rows=[];
const geometry=(n:any)=>({width:n.width,height:n.height,nodes:n.children.map((c:any)=>({id:c.id,x:c.x,y:c.y,width:c.width,height:c.height,ports:c.ports.map((p:any)=>({id:p.id,x:p.x,y:p.y,width:p.width,height:p.height}))})),edges:n.edges.map((e:any)=>({id:e.id,junctions:[...(e.junctionPoints??[])].sort((a:any,b:any)=>a.x-b.x||a.y-b.y),sections:e.sections?.map((s:any)=>({start:s.startPoint,bends:s.bendPoints??[],end:s.endPoint}))}))});
for(const direction of ["RIGHT","LEFT","DOWN","UP"] as const) for(let seed=1;seed<=50;seed++){
 const input=sharedPortFixture(seed,direction),before=await new Before().layout(structuredClone(input)),after=await new Native().layout(structuredClone(input)),elk=await new Oracle().layout(structuredClone(input) as never);
 rows.push({seed,direction,input,before,after,elk,beforeExact:isDeepStrictEqual(geometry(before),geometry(elk)),afterExact:isDeepStrictEqual(geometry(after),geometry(elk))});
}
fs.writeFileSync('.scratch/hypersegments-shared-port-final.json',JSON.stringify({rows},null,2));
console.log({beforeExact:rows.filter(r=>r.beforeExact).length,afterExact:rows.filter(r=>r.afterExact).length,failures:rows.filter(r=>!r.afterExact).map(r=>r.seed)});