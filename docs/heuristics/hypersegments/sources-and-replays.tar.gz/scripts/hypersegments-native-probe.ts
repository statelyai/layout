import fs from 'node:fs';
import {createGraph} from '@statelyai/graph';
import * as Native from './hypersegments-final-source/src';
import * as Before from './segment-engine-fixed-source/src';
import Oracle from 'elkjs/lib/elk.bundled.js';
import {measureQuality} from '../scripts/heuristic-quality.mjs';
import {toElkInput,fromElkOutput} from '../scripts/heuristic-elk-comparison.mjs';
const corpus=JSON.parse(fs.readFileSync('docs/heuristics/vertical-center-fresh-parity/seed-3468112780/corpus.json','utf8'));
const report:any={baseSeed:corpus.baseSeed,sourceHashes:JSON.parse(fs.readFileSync('.scratch/hypersegments-final-source/source-manifest.json','utf8')),rows:[]};
for(const c of corpus.cases){
const row:any={id:c.id,seed:c.seed,direction:c.direction,input:c.input};
const options:any={direction:c.direction,padding:24,spacing:{node:36,layer:56},nodeSettings:()=>({portConstraints:'FIXED_POS'}),portSettings:(p:any)=>({'port.side':p.data.side}),compound:()=>({header:{width:140,height:36,side:'top'}}),settings:{'compaction.postCompaction.strategy':'EDGE_LENGTH'}};
for(const [name,engine] of [['before',Before],['after',Native]] as const){
 console.log('running',c.id,name);
 try{
 const layout=engine.getLayeredLayout(createGraph(c.input),options);
 const routes=[...engine.getLayoutRoutes(layout)];
 row[name]={output:{...layout,routes},metrics:measureQuality({...layout,routes},c.input)};
 }catch(error){row[name]={error:String(error)}}
}
console.log('running',c.id,'elk');
try{
const input=toElkInput(c.input,c.direction);
input.layoutOptions['elk.layered.compaction.postCompaction.strategy']='EDGE_LENGTH';
row.elk={input};
const output=await new Oracle().layout(structuredClone(input));
row.elk.output=output;
const visual=fromElkOutput(output,c.input);
row.elk.metrics=measureQuality({...visual.layout,routes:[...visual.routes]},c.input);
}catch(error){row.elk={...row.elk,error:String(error)}}
report.rows.push(row);
fs.writeFileSync('.scratch/hypersegments-native-probe.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({id:c.id,...Object.fromEntries(['before','after','elk'].map(n=>[n,row[n].metrics??row[n].error]))}));
}
