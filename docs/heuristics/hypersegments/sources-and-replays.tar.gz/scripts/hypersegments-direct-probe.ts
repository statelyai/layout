import fs from 'node:fs';
import {isDeepStrictEqual} from 'node:util';
import {JavaRandom} from '../src/java-random';
import {createOrthogonalHypersegments,countOrthogonalHypersegmentCrossings} from '../src/layered/orthogonal-hypersegments';
import {elkOrthogonalHypersegments,elkHypersegmentCrossings,constraintOracleHash} from '../test/helpers/elk-constraint-oracle';
const rows:any[]=[];

{  const random = new JavaRandom(3468112780);
  for (let index = 0; index < 512; index++) {
    const ports: any[] = Array.from({ length: 2 + random.nextInt(10) }, (_, i) => ({
      id: `p${i}`,
      side: i % 2 ? "target" : "source",
      position: (random.nextInt(30) - 10) / 3,
    }));
    const connections: Array<{ source: string; target: string }> = [];
    for (const source of ports.filter((p) => p.side === "source"))
      for (const target of ports.filter((p) => p.side === "target"))
        if (random.nextInt(4) === 0) {
          const backward = random.nextBoolean();
          connections.push({
            source: backward ? target.id : source.id,
            target: backward ? source.id : target.id,
          });
        }
    const input = { ports, connections };
    const actual=createOrthogonalHypersegments(ports,connections),expected=elkOrthogonalHypersegments(input);
    rows.push({kind:'groups',index,input,actual,expected,equal:isDeepStrictEqual(actual,expected)});
  }
}

{  const random = new JavaRandom(3468112780);
  for (let index = 0; index < 512; index++) {
    const count = 2 + random.nextInt(10),
      ports: any[] = [];
    for (const side of ["source", "target"] as const)
      for (let i = 0; i < count; i++) ports.push({ id: `${side}${i}`, side, position: i });
    const connections: Array<{ source: string; target: string }> = [];
    for (const source of ports.filter((p) => p.side === "source"))
      for (const target of ports.filter((p) => p.side === "target"))
        if (random.nextInt(7) === 0) connections.push({ source: source.id, target: target.id });
    const input = { ports, connections };
    const actual=countOrthogonalHypersegmentCrossings(ports,connections),expected=elkHypersegmentCrossings(input);
    rows.push({kind:'crossings',index,input,actual,expected,equal:isDeepStrictEqual(actual,expected)});
  }
}
fs.writeFileSync('docs/heuristics/hypersegments/direct-probe.json',JSON.stringify({workerHash:constraintOracleHash,rows},(_k,v)=>v instanceof Map?[...v]:v,2));console.log({cases:rows.length,equal:rows.filter(r=>r.equal).length});